-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 03, 2025 at 09:49 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dmrp`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `updatefinancials` (IN `growthrate` FLOAT, IN `id` INT, IN `years_passed` INT)   BEGIN
    UPDATE financialdata
    JOIN popinfo ON financialdata.findataID = popinfo.nationpop
    SET 
        financialdata.GDP = financialdata.GDP * POW(1 + (growthrate / 100), years_passed), 
        financialdata.gdppercapita = financialdata.GDP / popinfo.population  
    WHERE financialdata.findataID = id;  
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `atpolicies`
-- (See below for the actual view)
--
CREATE TABLE `atpolicies` (
`categoryName` varchar(50)
,`policyName` tinytext
,`policyStatus` tinytext
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `atprojects`
-- (See below for the actual view)
--
CREATE TABLE `atprojects` (
`projectName` tinytext
,`projectDescription` longtext
,`completionDate` year(4)
,`secrecy` enum('SECRET','CLASSIFIED')
,`global` tinyint(1)
,`link` varchar(200)
);

-- --------------------------------------------------------

--
-- Table structure for table `financialdata`
--

CREATE TABLE `financialdata` (
  `findataID` int(11) NOT NULL,
  `GDP` double NOT NULL,
  `gdppercapita` double NOT NULL,
  `gdpgrowth` float NOT NULL,
  `currvsUSD` tinyint(4) NOT NULL DEFAULT 10 COMMENT 'Value of currency to USD',
  `currName` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `locationID` int(11) NOT NULL,
  `locationName` varchar(50) NOT NULL,
  `locationType` varchar(50) NOT NULL,
  `population` int(11) DEFAULT NULL,
  `locSector` int(11) DEFAULT NULL,
  `locDesc` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `majorsectors`
--

CREATE TABLE `majorsectors` (
  `sectorID` int(11) NOT NULL,
  `Sector Name` varchar(50) NOT NULL,
  `sectorType` varchar(50) NOT NULL,
  `sectorDesc` longtext DEFAULT NULL COMMENT 'Flavour lore desc for sector'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `minorsectors`
--

CREATE TABLE `minorsectors` (
  `sectorID` int(11) NOT NULL,
  `Sector Name` varchar(50) NOT NULL,
  `sectorType` varchar(50) NOT NULL,
  `superSector` int(11) DEFAULT NULL,
  `sectorDesc` longtext DEFAULT NULL COMMENT 'Optional flavour desc for minor sector'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Planets, space stations, etc';

-- --------------------------------------------------------

--
-- Table structure for table `nation`
--

CREATE TABLE `nation` (
  `nationID` int(11) NOT NULL,
  `nationName` varchar(50) NOT NULL,
  `nationCapital` varchar(50) NOT NULL,
  `nationDesc` longtext DEFAULT NULL COMMENT 'Optional Lore Description'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nationloc`
--

CREATE TABLE `nationloc` (
  `ownerID` int(11) NOT NULL,
  `locID` int(11) NOT NULL,
  `ownershipPercentage` float(1,0) DEFAULT NULL,
  `details` tinytext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nationmisector`
--

CREATE TABLE `nationmisector` (
  `ownerID` int(11) NOT NULL,
  `sectorID` int(11) NOT NULL,
  `ownershipPercentage` float(1,0) DEFAULT NULL,
  `details` tinytext DEFAULT NULL COMMENT 'Nature of ownership'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nationmjsector`
--

CREATE TABLE `nationmjsector` (
  `ownerID` int(11) NOT NULL,
  `mjSectorID` int(11) NOT NULL,
  `ownershipPercentage` float(1,0) DEFAULT NULL,
  `details` tinytext DEFAULT NULL COMMENT 'Nature of ownership/partnership details'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nationpolicies`
--

CREATE TABLE `nationpolicies` (
  `nationID` int(11) NOT NULL,
  `PolicyID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nationprojects`
--

CREATE TABLE `nationprojects` (
  `nationID` int(11) NOT NULL,
  `projectID` int(11) NOT NULL,
  `ownership` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `policies`
--

CREATE TABLE `policies` (
  `policyID` int(11) NOT NULL,
  `policyCategory` int(11) NOT NULL,
  `policyName` tinytext NOT NULL,
  `policyStatus` tinytext NOT NULL,
  `policyDesc` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `policycategories`
--

CREATE TABLE `policycategories` (
  `categoryID` int(11) NOT NULL,
  `categoryName` varchar(50) NOT NULL,
  `categoryDesc` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `popinfo`
--

CREATE TABLE `popinfo` (
  `nationpop` int(11) NOT NULL,
  `population` bigint(20) NOT NULL,
  `popgrowth` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `projectID` int(11) NOT NULL,
  `projectTypeID` int(11) NOT NULL,
  `projectName` tinytext NOT NULL,
  `completionDate` year(4) NOT NULL,
  `projectDescription` longtext NOT NULL,
  `complete` tinyint(1) NOT NULL,
  `secrecy` enum('SECRET','CLASSIFIED') NOT NULL,
  `global` tinyint(1) NOT NULL DEFAULT 0,
  `link` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projecttype`
--

CREATE TABLE `projecttype` (
  `typeID` int(11) NOT NULL,
  `projectType` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `sharedprojects`
-- (See below for the actual view)
--
CREATE TABLE `sharedprojects` (
`projectName` tinytext
,`projectDescription` longtext
,`completionDate` year(4)
,`secrecy` enum('SECRET','CLASSIFIED')
,`global` tinyint(1)
,`link` varchar(200)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `ucpolicies`
-- (See below for the actual view)
--
CREATE TABLE `ucpolicies` (
`categoryName` varchar(50)
,`policyName` tinytext
,`policyStatus` tinytext
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `ucprojects`
-- (See below for the actual view)
--
CREATE TABLE `ucprojects` (
`projectName` tinytext
,`projectDescription` longtext
,`completionDate` year(4)
,`secrecy` enum('SECRET','CLASSIFIED')
,`global` tinyint(1)
,`link` varchar(200)
);

-- --------------------------------------------------------

--
-- Table structure for table `worlddata`
--

CREATE TABLE `worlddata` (
  `worldDataID` int(11) NOT NULL,
  `date` year(4) NOT NULL,
  `mapLink` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `worlddata`
--
DELIMITER $$
CREATE TRIGGER `UpdateFinancialDataAfterWorldDataUpdate` AFTER UPDATE ON `worlddata` FOR EACH ROW BEGIN
    DECLARE years_passed INT;
    SET years_passed = NEW.date - OLD.date;

    IF years_passed > 0 THEN
        UPDATE financialdata
        SET GDP = GDP * POW(1 + (gdpgrowth / 100), years_passed),
            gdppercapita = GDP / (SELECT population FROM popinfo WHERE nationpop = financialdata.findataID)
        WHERE findataID IN (SELECT findataID FROM financialdata);
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UpdateProjectCompletion` AFTER UPDATE ON `worlddata` FOR EACH ROW BEGIN
    -- Update the 'projects' table
    UPDATE projects
    SET complete = 1  -- Mark project as complete
    WHERE NEW.date > projects.completionDate  -- Date condition
    AND projects.complete = 0;  -- Only update projects that are not already marked complete
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updatePopulation` AFTER UPDATE ON `worlddata` FOR EACH ROW BEGIN
    DECLARE time_passed INT;
    DECLARE current_year INT;
    DECLARE previous_year INT;
    DECLARE population BIGINT;
    DECLARE growth_rate FLOAT;
    DECLARE done INT DEFAULT 0;

    DECLARE popinfo_cursor CURSOR FOR
        SELECT population, popgrowth
        FROM popinfo;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    SET current_year = NEW.date;
    SET previous_year = OLD.date;

    SET time_passed = current_year - previous_year;

    IF time_passed > 0 THEN
        OPEN popinfo_cursor;

        read_loop: LOOP
            FETCH popinfo_cursor INTO population, growth_rate;
            IF done THEN
                LEAVE read_loop;
            END IF;

            SET population = population * POW(1 + (growth_rate / 100), time_passed);

            UPDATE popinfo
            SET population = ROUND(population);

        END LOOP;

        CLOSE popinfo_cursor;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure for view `atpolicies`
--
DROP TABLE IF EXISTS `atpolicies`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `atpolicies`  AS SELECT `pc`.`categoryName` AS `categoryName`, `p`.`policyName` AS `policyName`, `p`.`policyStatus` AS `policyStatus` FROM ((`policycategories` `pc` join `policies` `p` on(`pc`.`categoryID` = `p`.`policyCategory`)) join `nationpolicies` `np` on(`p`.`policyID` = `np`.`PolicyID`)) WHERE `np`.`nationID` = 2 ;

-- --------------------------------------------------------

--
-- Structure for view `atprojects`
--
DROP TABLE IF EXISTS `atprojects`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `atprojects`  AS SELECT `p`.`projectName` AS `projectName`, `p`.`projectDescription` AS `projectDescription`, `p`.`completionDate` AS `completionDate`, `p`.`secrecy` AS `secrecy`, `p`.`global` AS `global`, `p`.`link` AS `link` FROM (`projects` `p` join `nationprojects` `np` on(`p`.`projectID` = `np`.`nationID`)) WHERE `np`.`nationID` = 2 AND `np`.`ownership` = 1 ;

-- --------------------------------------------------------

--
-- Structure for view `sharedprojects`
--
DROP TABLE IF EXISTS `sharedprojects`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sharedprojects`  AS SELECT DISTINCT `p`.`projectName` AS `projectName`, `p`.`projectDescription` AS `projectDescription`, `p`.`completionDate` AS `completionDate`, `p`.`secrecy` AS `secrecy`, `p`.`global` AS `global`, `p`.`link` AS `link` FROM (`projects` `p` join `nationprojects` `np` on(`p`.`projectID` = `np`.`nationID`)) WHERE `np`.`ownership` = 0 ;

-- --------------------------------------------------------

--
-- Structure for view `ucpolicies`
--
DROP TABLE IF EXISTS `ucpolicies`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ucpolicies`  AS SELECT `pc`.`categoryName` AS `categoryName`, `p`.`policyName` AS `policyName`, `p`.`policyStatus` AS `policyStatus` FROM ((`policycategories` `pc` join `policies` `p` on(`pc`.`categoryID` = `p`.`policyCategory`)) join `nationpolicies` `np` on(`p`.`policyID` = `np`.`PolicyID`)) WHERE `np`.`nationID` = 1 ;

-- --------------------------------------------------------

--
-- Structure for view `ucprojects`
--
DROP TABLE IF EXISTS `ucprojects`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ucprojects`  AS SELECT `p`.`projectName` AS `projectName`, `p`.`projectDescription` AS `projectDescription`, `p`.`completionDate` AS `completionDate`, `p`.`secrecy` AS `secrecy`, `p`.`global` AS `global`, `p`.`link` AS `link` FROM (`projects` `p` join `nationprojects` `np` on(`p`.`projectID` = `np`.`nationID`)) WHERE `np`.`nationID` = 1 AND `np`.`ownership` = 1 ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `financialdata`
--
ALTER TABLE `financialdata`
  ADD PRIMARY KEY (`findataID`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`locationID`),
  ADD UNIQUE KEY `locnameUnique` (`locationName`),
  ADD KEY `fklocmjsector` (`locSector`);

--
-- Indexes for table `majorsectors`
--
ALTER TABLE `majorsectors`
  ADD PRIMARY KEY (`sectorID`),
  ADD UNIQUE KEY `snameUnique` (`Sector Name`);

--
-- Indexes for table `minorsectors`
--
ALTER TABLE `minorsectors`
  ADD PRIMARY KEY (`sectorID`),
  ADD UNIQUE KEY `msectorUnique` (`Sector Name`),
  ADD KEY `fksectorsupersector` (`superSector`);

--
-- Indexes for table `nation`
--
ALTER TABLE `nation`
  ADD PRIMARY KEY (`nationID`),
  ADD UNIQUE KEY `nameUnique` (`nationName`);

--
-- Indexes for table `nationloc`
--
ALTER TABLE `nationloc`
  ADD KEY `fklocowner` (`ownerID`),
  ADD KEY `fkloc` (`locID`);

--
-- Indexes for table `nationmisector`
--
ALTER TABLE `nationmisector`
  ADD KEY `fkmiloc` (`sectorID`),
  ADD KEY `fkmiowner` (`ownerID`);

--
-- Indexes for table `nationmjsector`
--
ALTER TABLE `nationmjsector`
  ADD KEY `fkmjowner` (`ownerID`),
  ADD KEY `fkmjsector` (`mjSectorID`);

--
-- Indexes for table `nationpolicies`
--
ALTER TABLE `nationpolicies`
  ADD KEY `fknationpoliciesnation` (`nationID`),
  ADD KEY `fknationpoliciespolicy` (`PolicyID`);

--
-- Indexes for table `nationprojects`
--
ALTER TABLE `nationprojects`
  ADD KEY `fknationprojectsnation` (`nationID`),
  ADD KEY `fknationprojectsproject` (`projectID`);

--
-- Indexes for table `policies`
--
ALTER TABLE `policies`
  ADD PRIMARY KEY (`policyID`),
  ADD KEY `fkpolicyPcategory` (`policyCategory`);

--
-- Indexes for table `policycategories`
--
ALTER TABLE `policycategories`
  ADD PRIMARY KEY (`categoryID`),
  ADD UNIQUE KEY `catnameUnique` (`categoryName`);

--
-- Indexes for table `popinfo`
--
ALTER TABLE `popinfo`
  ADD KEY `fknationpopulation` (`nationpop`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`projectID`),
  ADD UNIQUE KEY `pnameUnique` (`projectName`) USING HASH,
  ADD KEY `fkprojectType` (`projectTypeID`);

--
-- Indexes for table `projecttype`
--
ALTER TABLE `projecttype`
  ADD PRIMARY KEY (`typeID`),
  ADD UNIQUE KEY `typeUnique` (`projectType`) USING HASH;

--
-- Indexes for table `worlddata`
--
ALTER TABLE `worlddata`
  ADD PRIMARY KEY (`worldDataID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `financialdata`
--
ALTER TABLE `financialdata`
  MODIFY `findataID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `locationID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `majorsectors`
--
ALTER TABLE `majorsectors`
  MODIFY `sectorID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `minorsectors`
--
ALTER TABLE `minorsectors`
  MODIFY `sectorID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nation`
--
ALTER TABLE `nation`
  MODIFY `nationID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `policies`
--
ALTER TABLE `policies`
  MODIFY `policyID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `policycategories`
--
ALTER TABLE `policycategories`
  MODIFY `categoryID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `projectID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `projecttype`
--
ALTER TABLE `projecttype`
  MODIFY `typeID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `worlddata`
--
ALTER TABLE `worlddata`
  MODIFY `worldDataID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `financialdata`
--
ALTER TABLE `financialdata`
  ADD CONSTRAINT `fkfindatnation` FOREIGN KEY (`findataID`) REFERENCES `nation` (`nationID`);

--
-- Constraints for table `locations`
--
ALTER TABLE `locations`
  ADD CONSTRAINT `fklocmjsector` FOREIGN KEY (`locSector`) REFERENCES `minorsectors` (`sectorID`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `minorsectors`
--
ALTER TABLE `minorsectors`
  ADD CONSTRAINT `fksectorsupersector` FOREIGN KEY (`superSector`) REFERENCES `majorsectors` (`sectorID`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `nationloc`
--
ALTER TABLE `nationloc`
  ADD CONSTRAINT `fkloc` FOREIGN KEY (`locID`) REFERENCES `locations` (`locationID`),
  ADD CONSTRAINT `fklocowner` FOREIGN KEY (`ownerID`) REFERENCES `nation` (`nationID`);

--
-- Constraints for table `nationmisector`
--
ALTER TABLE `nationmisector`
  ADD CONSTRAINT `fkmiloc` FOREIGN KEY (`sectorID`) REFERENCES `minorsectors` (`sectorID`),
  ADD CONSTRAINT `fkmiowner` FOREIGN KEY (`ownerID`) REFERENCES `nation` (`nationID`);

--
-- Constraints for table `nationmjsector`
--
ALTER TABLE `nationmjsector`
  ADD CONSTRAINT `fkmjowner` FOREIGN KEY (`ownerID`) REFERENCES `nation` (`nationID`),
  ADD CONSTRAINT `fkmjsector` FOREIGN KEY (`mjSectorID`) REFERENCES `majorsectors` (`sectorID`);

--
-- Constraints for table `nationpolicies`
--
ALTER TABLE `nationpolicies`
  ADD CONSTRAINT `fknationpoliciesnation` FOREIGN KEY (`nationID`) REFERENCES `nation` (`nationID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fknationpoliciespolicy` FOREIGN KEY (`PolicyID`) REFERENCES `policies` (`policyID`) ON UPDATE CASCADE;

--
-- Constraints for table `nationprojects`
--
ALTER TABLE `nationprojects`
  ADD CONSTRAINT `fknationprojectsnation` FOREIGN KEY (`nationID`) REFERENCES `nation` (`nationID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fknationprojectsproject` FOREIGN KEY (`projectID`) REFERENCES `projects` (`projectID`) ON UPDATE CASCADE;

--
-- Constraints for table `policies`
--
ALTER TABLE `policies`
  ADD CONSTRAINT `fkpolicyPcategory` FOREIGN KEY (`policyCategory`) REFERENCES `policycategories` (`categoryID`);

--
-- Constraints for table `popinfo`
--
ALTER TABLE `popinfo`
  ADD CONSTRAINT `fknationpopulation` FOREIGN KEY (`nationpop`) REFERENCES `nation` (`nationID`);

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `fkprojectType` FOREIGN KEY (`projectTypeID`) REFERENCES `projecttype` (`typeID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
